# SellerSprite Skills — System Prompt Bundle

版本: **v0.1.16**  |  Skills 数量: **27**

本压缩包包含 SellerSprite CLI 提供的 AI 技能体系的两种机器可读形式，
方便你在不安装 CLI 的前提下，把这套能力注入到任意 LLM / Agent 系统中。

---

## 📦 文件清单

| 文件 | 类型 | 用途 |
|------|------|------|
| `skills-system-prompt.md` | Markdown | 用于直接注入 LLM 的 system prompt |
| `skills.json` | JSON | 程序化使用：检索、动态加载、按需注入 |
| `README.md` | Markdown | 本文档 |

---

## 1. `skills-system-prompt.md` 用法

一份合成好的 Markdown，将所有 27 个 Skill 的执行步骤、参数、引用 API 文档
全部内联在一起，可直接作为 system prompt 灌入 LLM。

### 适用场景

- 自建 Agent / Chatbot，希望让模型一次性掌握全部 Skill
- 需要在不依赖 MCP 客户端的环境中复用这套技能
- 评测、研究、Prompt 工程

### 使用示例 — Anthropic API (Python)

```python
import anthropic

with open("skills-system-prompt.md", encoding="utf-8") as f:
    system_prompt = f.read()

client = anthropic.Anthropic()
resp = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=2048,
    system=system_prompt,
    messages=[{"role": "user", "content": "帮我找月销 500+ 的 FBM 产品"}],
)
print(resp.content[0].text)
```

### 使用示例 — OpenAI API (Python)

```python
from openai import OpenAI

with open("skills-system-prompt.md", encoding="utf-8") as f:
    system_prompt = f.read()

client = OpenAI()
resp = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "帮我找月销 500+ 的 FBM 产品"},
    ],
)
print(resp.choices[0].message.content)
```

### 使用示例 — 本地 LLM (Ollama / vLLM / LM Studio)

将文件内容粘贴到对应推理框架的 system prompt 配置项，
或通过 OpenAI 兼容 API 与上面示例相同方式注入。

> 提示：`skills-system-prompt.md` 体积约 200 KB / ~80K tokens，
> 注入前请确认目标模型支持的上下文窗口足够（建议 128K+）。

---

## 2. `skills.json` 用法

结构化数据，每个 Skill 一条记录，字段如下：

| 字段 | 类型 | 说明 |
|------|------|------|
| `name` | string | Skill 中文名 |
| `slug` | string | Skill 标识符（文件名） |
| `category` | string | `comprehensive`（综合分析）或 `tactical`（战术选品） |
| `content` | string | Skill 完整 Markdown 内容（步骤、参数等） |
| `referenced_tools` | string[] | 该 Skill 引用的 MCP 工具名列表 |
| `api_docs` | object | `{工具名: 内联 API 文档}` 映射 |

### 适用场景

- 检索：按用户意图模糊匹配最合适的 Skill
- 动态注入：仅把需要的 Skill 加入 prompt，节省 token
- 二次加工：转成你自己平台的 prompt template / 知识库格式
- 评测：批量跑 Skill 的端到端验证

### 使用示例 — 按需注入

```python
import json

with open("skills.json", encoding="utf-8") as f:
    skills = json.load(f)

# 用户问到 FBM 产品 → 只把 fbm-intercept 这一条注入
needed = next(s for s in skills if s["slug"] == "fbm-intercept")
system_prompt = f"你将按以下 Skill 执行：\n\n{needed['content']}"
```

### 使用示例 — 按类别筛选

```python
comp = [s for s in skills if s["category"] == "comprehensive"]
tac  = [s for s in skills if s["category"] == "tactical"]
print(f"综合分析 {len(comp)} 个，战术选品 {len(tac)} 个")
```

### 使用示例 — 工具引用图谱

```python
from collections import Counter

# 哪些 MCP 工具被最多 Skill 引用
counter = Counter(t for s in skills for t in s["referenced_tools"])
print(counter.most_common(5))
```

---

## 3. 两种格式怎么选？

- **想"零代码"快速上手** → 用 `skills-system-prompt.md`，整包 system prompt 一灌即可
- **想精细控制 token 与上下文** → 用 `skills.json`，按需挑选注入
- **企业级 Agent 系统** → 推荐 `skills.json` + 自建检索（向量库 / BM25 / 标签）

---

## 4. 配合 MCP 工具使用

Skill 内的执行步骤都会调用形如 `mcp__sellersprite__<tool_name>` 的工具。
若要让模型真正"跑通"这些工具，你的 Agent 需要接入 SellerSprite MCP Server：

- MCP 接入文档: <https://open.sellersprite.com/mcp>
- API 文档: <https://open.sellersprite.com/api>
- PyPI 包: <https://pypi.org/project/sellersprite-cli>
- GitHub: <https://github.com/opensellersprite/sellersprite-cli>
- Gitee: <https://gitee.com/opensellersprite/sellersprite-cli>

若仅做 prompt 实验、暂不接入真实 API，可让模型 mock 工具返回值，仍然能验证 Skill 的逻辑结构。

---

## 5. 版本与更新

- 当前版本: **v0.1.16**（与 `sellersprite-cli` 主包版本同步，可在本 README 顶部查看）
- 更新方式: 重新拉取最新 `skills-system-prompt.zip` 覆盖即可
- 如需保留多版本，请下载后自行重命名（如 `skills-system-prompt-v0.1.16.zip`）

---

## 6. 反馈

- 邮箱: open.seller.sprite@gmail.com
- Issues: <https://github.com/opensellersprite/sellersprite-cli/issues>

© SellerSprite. All rights reserved.
